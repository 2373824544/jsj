<form name="form2" method="post" enctype="multipart/form-data" action="upload_excel.php">
<input type="hidden" name="leadExcel" value="true">
<table align="center" width="90%" border="0">
<tr>
   <td>
    <input type="file" name="inputExcel"><input type="submit" name="import" value="��������">
   </td>
</tr>
</table>
</form>